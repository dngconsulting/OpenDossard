# Dossardeur — Brand Kit

Contenu de ce paquet :

- `brand-kit.html` — Page complète du kit graphique (à ouvrir dans un navigateur)
- `logos/svg/` — Versions SVG vectorielles (idéal pour le web et tout usage redimensionnable)
- `logos/png/` — Versions PNG 1200×651 px (transparence supportée pour `logo-transparent`)
- `logos/jpg/` — Versions JPG 1200×651 px qualité 92 (transparence remplacée par blanc)

## Déclinaisons

| Fichier                    | Fond                 | Usage suggéré                              |
|----------------------------|----------------------|---------------------------------------------|
| `logo-navy-dark.*`         | `#0f172a`            | Hero, sidebar (canonique)                  |
| `logo-navy-mid.*`          | `#1e3a5f`            | Bandeau secondaire                         |
| `logo-primary-dark.*`      | `#2d4889`            | Variante saturée                           |
| `logo-black.*`             | `#000000`            | Impression, contraste max                  |
| `logo-hero-gradient.*`     | Gradient hero        | Splash, bannière marketing                 |

## Invariants du logo

- Moyeu arrière (point gauche) : toujours bleu `#365AAF`
- Essieu (barre) : toujours gris `#BFBFBF`
- Moyeu avant (point droit) : toujours blanc `#FFFFFF`

Seule la couleur de fond varie d'une déclinaison à l'autre.
